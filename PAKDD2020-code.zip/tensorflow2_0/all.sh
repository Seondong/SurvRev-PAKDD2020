python survrevtensorflow2.py --store_id store_C --training_length 180
python survrevtensorflow2.py --store_id store_C --training_length 180
python survrevtensorflow2.py --store_id store_C --training_length 180
python survrevtensorflow2.py --store_id store_C --training_length 180
python survrevtensorflow2.py --store_id store_C --training_length 180
python survrevtensorflow2.py --store_id store_C --training_length 240
python survrevtensorflow2.py --store_id store_C --training_length 240
python survrevtensorflow2.py --store_id store_C --training_length 240
python survrevtensorflow2.py --store_id store_C --training_length 240
python survrevtensorflow2.py --store_id store_C --training_length 240
python survrevtensorflow2.py --store_id store_C --training_length 300
python survrevtensorflow2.py --store_id store_C --training_length 300
python survrevtensorflow2.py --store_id store_C --training_length 300
python survrevtensorflow2.py --store_id store_C --training_length 300
python survrevtensorflow2.py --store_id store_C --training_length 300
python survrevtensorflow2.py --store_id store_C --training_length 120
python survrevtensorflow2.py --store_id store_C --training_length 120
python survrevtensorflow2.py --store_id store_C --training_length 120
python survrevtensorflow2.py --store_id store_C --training_length 120
python survrevtensorflow2.py --store_id store_C --training_length 120
python survrevtensorflow2.py --store_id store_C --training_length 60
python survrevtensorflow2.py --store_id store_C --training_length 60
python survrevtensorflow2.py --store_id store_C --training_length 60
python survrevtensorflow2.py --store_id store_C --training_length 60
python survrevtensorflow2.py --store_id store_C --training_length 60
python survrevtensorflow2.py --store_id store_B --training_length 180
python survrevtensorflow2.py --store_id store_B --training_length 180
python survrevtensorflow2.py --store_id store_B --training_length 180
python survrevtensorflow2.py --store_id store_B --training_length 180
python survrevtensorflow2.py --store_id store_B --training_length 180
python survrevtensorflow2.py --store_id store_B --training_length 240
python survrevtensorflow2.py --store_id store_B --training_length 240
python survrevtensorflow2.py --store_id store_B --training_length 240
python survrevtensorflow2.py --store_id store_B --training_length 240
python survrevtensorflow2.py --store_id store_B --training_length 240
python survrevtensorflow2.py --store_id store_B --training_length 300
python survrevtensorflow2.py --store_id store_B --training_length 300
python survrevtensorflow2.py --store_id store_B --training_length 300
python survrevtensorflow2.py --store_id store_B --training_length 300
python survrevtensorflow2.py --store_id store_B --training_length 300
python survrevtensorflow2.py --store_id store_B --training_length 120
python survrevtensorflow2.py --store_id store_B --training_length 120
python survrevtensorflow2.py --store_id store_B --training_length 120
python survrevtensorflow2.py --store_id store_B --training_length 120
python survrevtensorflow2.py --store_id store_B --training_length 120
python survrevtensorflow2.py --store_id store_B --training_length 60
python survrevtensorflow2.py --store_id store_B --training_length 60
python survrevtensorflow2.py --store_id store_B --training_length 60
python survrevtensorflow2.py --store_id store_B --training_length 60
python survrevtensorflow2.py --store_id store_B --training_length 60
python survrevtensorflow2.py --store_id store_A --training_length 180
python survrevtensorflow2.py --store_id store_A --training_length 180
python survrevtensorflow2.py --store_id store_A --training_length 180
python survrevtensorflow2.py --store_id store_A --training_length 180
python survrevtensorflow2.py --store_id store_A --training_length 180
python survrevtensorflow2.py --store_id store_A --training_length 240
python survrevtensorflow2.py --store_id store_A --training_length 240
python survrevtensorflow2.py --store_id store_A --training_length 240
python survrevtensorflow2.py --store_id store_A --training_length 240
python survrevtensorflow2.py --store_id store_A --training_length 240
python survrevtensorflow2.py --store_id store_A --training_length 300
python survrevtensorflow2.py --store_id store_A --training_length 300
python survrevtensorflow2.py --store_id store_A --training_length 300
python survrevtensorflow2.py --store_id store_A --training_length 300
python survrevtensorflow2.py --store_id store_A --training_length 300
python survrevtensorflow2.py --store_id store_A --training_length 120
python survrevtensorflow2.py --store_id store_A --training_length 120
python survrevtensorflow2.py --store_id store_A --training_length 120
python survrevtensorflow2.py --store_id store_A --training_length 120
python survrevtensorflow2.py --store_id store_A --training_length 120
python survrevtensorflow2.py --store_id store_A --training_length 60
python survrevtensorflow2.py --store_id store_A --training_length 60
python survrevtensorflow2.py --store_id store_A --training_length 60
python survrevtensorflow2.py --store_id store_A --training_length 60
python survrevtensorflow2.py --store_id store_A --training_length 60

#python survrevtensorflow2.py --multiprocessing --train_epochs=100
#python survrevtensorflow2.py --multiprocessing --previous_visits=False --train_epochs=100
#python survrevtensorflow2.py --multiprocessing --train_epochs=100
#python survrevtensorflow2.py --multiprocessing --previous_visits=False --train_epochs=100
#python survrevtensorflow2.py --multiprocessing --train_epochs=100
#python survrevtensorflow2.py --multiprocessing --previous_visits=False --train_epochs=100
#python survrevtensorflow2.py --multiprocessing --train_epochs=100
#python survrevtensorflow2.py --multiprocessing --previous_visits=False --train_epochs=100
#python survrevtensorflow2.py --multiprocessing --train_epochs=1 --all_data
#python survrevtensorflow2.py --multiprocessing --previous_visits=False --train_epochs=1 --all_data
#python survrevtensorflow2.py --multiprocessing --train_epochs=1 --all_data
#python survrevtensorflow2.py --multiprocessing --previous_visits=False --train_epochs=1 --all_data
#python survrevtensorflow2.py --multiprocessing --train_epochs=1 --all_data
#python survrevtensorflow2.py --multiprocessing --previous_visits=False --train_epochs=1 --all_data
#python survrevtensorflow2.py --multiprocessing --train_epochs=1 --all_data
#python survrevtensorflow2.py --multiprocessing --previous_visits=False --train_epochs=1 --all_data

#python survrevtensorflow2.py --multiprocessing --train_epochs=25 --all_data
#python survrevtensorflow2.py --multiprocessing --previous_visits=False --train_epochs=1 --all_data


#python survrevtensorflow2.py --multiprocessing --train_epochs=25 --all_data
#python survrevtensorflow2.py --multiprocessing --previous_visits=False --train_epochs=1 --all_data

#python survrevtensorflow2.py --store_id store_A --previous_visits=False --train_epochs 25
#python survrevtensorflow2.py --store_id store_A --previous_visits=True --train_epochs 25
#python survrevtensorflow2.py --store_id store_B --previous_visits=False --train_epochs 25
#python survrevtensorflow2.py --store_id store_B --previous_visits=True --train_epochs 25
#python survrevtensorflow2.py --store_id store_C --previous_visits=False --train_epochs 25
#python survrevtensorflow2.py --store_id store_C --previous_visits=True --train_epochs 25
#python survrevtensorflow2.py --store_id store_D --previous_visits=False --train_epochs 25
#python survrevtensorflow2.py --store_id store_D --previous_visits=True --train_epochs 25
#python survrevtensorflow2.py --store_id store_E --previous_visits=False --train_epochs 25
#python survrevtensorflow2.py --store_id store_E --previous_visits=True --train_epochs 25
#
#python survrevtensorflow2.py --store_id store_A --previous_visits=False --train_epochs 1 --all_data=True
#python survrevtensorflow2.py --store_id store_A --previous_visits=True --train_epochs 1 --all_data=True
#python survrevtensorflow2.py --store_id store_B --previous_visits=False --train_epochs 1 --all_data=True
#python survrevtensorflow2.py --store_id store_B --previous_visits=True --train_epochs 1 --all_data=True
#python survrevtensorflow2.py --store_id store_C --previous_visits=False --train_epochs 1 --all_data=True
#python survrevtensorflow2.py --store_id store_C --previous_visits=True --train_epochs 1 --all_data=True
#python survrevtensorflow2.py --store_id store_D --previous_visits=False --train_epochs 1 --all_data=True
#python survrevtensorflow2.py --store_id store_D --previous_visits=True --train_epochs 1 --all_data=True
#python survrevtensorflow2.py --store_id store_E --previous_visits=False --train_epochs 1 --all_data=True
#python survrevtensorflow2.py --store_id store_E --previous_visits=True --train_epochs 1 --all_data=True
